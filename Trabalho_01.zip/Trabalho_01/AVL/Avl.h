typedef struct Disciplina {
    int codD;
    char nome[50];
    int bloco;
    int cargHor;
    int altura;
    struct Disciplina *esq, *dir;
} Disciplina;

typedef struct Curso {
    int codC;
    char nome[70];
    int qtdBCurso;
    int semana;
    int altura;
    Disciplina *disciplinas;
    struct Curso *esq, *dir;
} Curso;



Curso* existeCurso(Curso *raiz, int codC);



// horária
