void balancear(Curso **raiz);
int fb(Curso *no);
void rotacaoEsquerda(Curso **raiz);
void rotacaoDireita(Curso **raiz);


int pegarAltura(Curso *raiz);
void atualizarAltura(Curso *raiz);

void balancearDis(Disciplina **raiz);
int fbDis(Disciplina *raiz);
int pegarAlturaDis(Disciplina *raiz);
void atualizarAlturaDis(Disciplina *raiz);
void rotacaoEsqDis(Disciplina **raiz);
void rotacaoDirDis(Disciplina **raiz);